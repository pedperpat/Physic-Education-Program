﻿using System;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Windows.Forms;

namespace Physics
{
    public partial class MainScreen : Form
    {
        protected Equations equations;
        public MainScreen()
        {
            InitializeComponent();
        }

        private void conceptsBt_Click(object sender, EventArgs e)
        {
            Concepts concepts = new Concepts();
            //Close();
            Hide();
            concepts.ShowDialog();
        }

        private void constantsBt_Click(object sender, EventArgs e)
        {
            Constants cons = new Constants();
            //Close();
            Hide();
            cons.ShowDialog();
        }

        private void problemsBt_Click(object sender, EventArgs e)
        {
            ProblemsReview problems = new ProblemsReview();
            //Close();
            Hide();
            problems.ShowDialog();
        }

        private void equationsBt_Click(object sender, EventArgs e)
        {
            Equations eq = new Equations();
            Hide();
            eq.ShowDialog();
        }

        private void helpBt_Click(object sender, EventArgs e)
        {
            HelpScreen help = new HelpScreen();
            Hide();
            help.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChangeLog changelog = new ChangeLog();
            Hide();
            changelog.ShowDialog();
        }

        private void toVideosBt_Click(object sender, EventArgs e)
        {
            VideoReviewForm video = new VideoReviewForm();
            Hide();
            video.ShowDialog();
        }

        private void toHistoricalBt_Click(object sender, EventArgs e)
        {
            Historical historial = new Historical();
            Hide();
            historial.ShowDialog();
        }

        public static void CheckLang()
        {
            
        }

        // Method to change the languaje using windows forms resource files stored at Lang directory.
        private void changeLanBt_Click(object sender, EventArgs e)
        {
            // If english radio button is checked, then change the lang to english.
            if (englishLan.Checked == true)
            {
                Assembly english = Assembly.Load("Physics");
                ResourceManager rm = new ResourceManager("Physics.Lang.LangEn", english);

                // Change the textbox values to the new texts from the internal resource file.
                titleLb.Text = rm.GetString("title");
                ConceptsLb.Text = rm.GetString("concepts");
                conceptsBt.Text = rm.GetString("goConcepts");
                EquationsLb.Text = rm.GetString("simpleEq");
                equationsBt.Text = rm.GetString("goEquations");
                helpBt.Text = rm.GetString("help");
                helpLb.Text = rm.GetString("goHelp");
                toVideosBt.Text = rm.GetString("goVideoReviews");
                videoReviewLb.Text = rm.GetString("VideoReviews");
                ConstantsLb.Text = rm.GetString("constants");
                constantsBt.Text = rm.GetString("goConstants");
                problemsBt.Text = rm.GetString("goProblems");
                ProblemReviewLb.Text = rm.GetString("reviewProblems");
                VersionLb.Text = rm.GetString("version");
                numberVersionLb.Text = rm.GetString("numVersion");
                button1.Text = rm.GetString("loadChange");
                toHistoricalBt.Text = rm.GetString("showHistorical");
                changeLanBt.Text = rm.GetString("changeLang");
            } 
            else
            {
                CultureInfo ci = new CultureInfo("es-ES");
                Assembly spanish = Assembly.Load("Physics");
                ResourceManager rm = new ResourceManager("Physics.Lang.LangEs", spanish);

                // Change the textbox values to the new texts from the internal resource file.
                titleLb.Text = rm.GetString("titulo",ci);
                ConceptsLb.Text = rm.GetString("conceptos",ci);
                conceptsBt.Text = rm.GetString("irAConceptos", ci);
                EquationsLb.Text = rm.GetString("irAEcuaciones", ci);
                equationsBt.Text = rm.GetString("ecuacionessimples", ci);
                helpBt.Text = rm.GetString("ayuda", ci);
                helpLb.Text = rm.GetString("iraAyuda", ci);
                toVideosBt.Text = rm.GetString("IraVideos", ci);
                videoReviewLb.Text = rm.GetString("videosRepaso", ci);
                ConstantsLb.Text = rm.GetString("ConstantesmasUsadas", ci);
                constantsBt.Text = rm.GetString("irConstantes", ci);
                problemsBt.Text = rm.GetString("problemasRepaso", ci);
                ProblemReviewLb.Text = rm.GetString("problemasRepasoLb", ci);
                VersionLb.Text = rm.GetString("VersionActual", ci);
                numberVersionLb.Text = rm.GetString("numeroVersion", ci);
                button1.Text = rm.GetString("CargaRegistro", ci);
                toHistoricalBt.Text = rm.GetString("MuestraHistorial", ci);
                changeLanBt.Text = rm.GetString("CambiaLenguaje", ci);
            }
        }

        private void englishLan_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void spanishLan_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
