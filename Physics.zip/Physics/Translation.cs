﻿namespace Physics
{
    class Translator
    {
        protected Equations equations;
        protected ProblemsReview problems;
        protected ChangeLog changelog;
        protected Acceleration acceleration;
        protected Energy energy;
        protected HelpScreen helpscreen;
        protected InitialVandHmax initVHmax;
        protected Velocity velocity;
        public static string GetTranslation(string language, string sentence)
        {
            language = language.ToUpper();
            sentence = sentence.ToLower();

            switch (language)
            {
                case "ES":
                    switch (sentence)
                    {
                        case "addtr":
                            return "Añadir gasto o ingreso";
                        case "viewtr":
                            return "Ver las últimas transacciones";
                        case "monthtr":
                            return "Transacciones mensuales";
                        case "accountstr":
                            return "Totales de la cuenta";
                        case "searchtr":
                            return "Buscar";
                        case "exits":
                            return "Salir";
                        case "chosse":
                            return "Elija una opción: ";
                        case "askamount":
                            return "Introduzca la cantidad (C para cancelar): ";
                        case "askdesctr":
                            return "Introduzca la descripción: ";
                        case "askday":
                            return "Introduzca el día: ";
                        case "askmonth":
                            return "Introduzca el mes: ";
                        case "askyear":
                            return "Introduzca el año: ";
                        case "askaccount":
                            return "Introduzca la cuenta: ";
                        case "askcategory":
                            return "Introduzca la categoría: ";
                        case "invalidoption":
                            return "Opción no valida";
                        case "unknow":
                            return "Opción desconocida";
                        case "keypress":
                            return "Presiona una tecla para volver";
                        case "lchange":
                            return "Cambiar idioma";
                        case "langchoose":
                            return "Elige idioma (Español[ES], Ingles[EN])";
                        default:
                            return sentence;
                    }

                case "EN":
                    switch (sentence)
                    {
                        case "addtr":
                            return "Add expense or income";
                        case "viewtr":
                            return "View last Transactions";
                        case "monthtr":
                            return "Monthly Transactions";
                        case "accountstr":
                            return "Account totals";
                        case "searchtr":
                            return "Search";
                        case "exits":
                            return "Exit";
                        case "chosse":
                            return "Choose an option:";
                        case "askamount":
                            return "Enter the amount (C to cancel) ";
                        case "askdesctr":
                            return "Enter the description:";
                        case "askday":
                            return "Enter the day:";
                        case "askmonth":
                            return "Enter the month";
                        case "askyear":
                            return "Enter the year";
                        case "askaccount":
                            return "Enter account";
                        case "askcategory":
                            return "Enter category";
                        case "invalidoption":
                            return "Invalid option";
                        case "unknow":
                            return "Unknown option";
                        case "keypress":
                            return "Press a key to return";
                        case "lchange":
                            return "Change language";
                        case "langchoose":
                            return "Choose language (Spanish[ES], English[EN])";
                        default:
                            return sentence;
                    }
                default:
                    return sentence;
            }
        }
    }
}